
        async function treinarEPrever() {

            // Pegando elementos da tela
            const textoStatus = document.getElementById("status");
            const textoResultado = document.getElementById("resultado");

            // Pegando valor digitado pelo usuário
            const horasDigitadas = Number(document.getElementById("horas").value);

            textoStatus.innerText = "Status: Treinando a IA...";

            // =========================
            // 1. CRIAR O MODELO (neurônio)
            // =========================
            const modelo = tf.sequential();
            modelo.add(tf.layers.dense({
                units: 1,
                inputShape: [1]
            }));

            // =========================
            // 2. COMPILAR O MODELO
            // =========================
            modelo.compile({
                loss: 'meanSquaredError',
                optimizer: 'sgd'
            });

            // =========================
            // 3. DADOS DE TREINO
            // X = horas de estudo
            // Y = notas
            // =========================
            const dadosEntrada = tf.tensor2d([1, 2, 3, 4], [4, 1]);
            const dadosSaida = tf.tensor2d([2, 4, 6, 8], [4, 1]);

            // =========================
            // 4. TREINAMENTO
            // A IA aprende com os dados
            // =========================
            await modelo.fit(dadosEntrada, dadosSaida, {
                epochs: 200
            });

            textoStatus.innerText = "Status: IA treinada!";

            // =========================
            // 5. PREVISÃO
            // =========================
            const previsao = modelo.predict(
                tf.tensor2d([horasDigitadas], [1, 1])
            );

            // Convertendo resultado para número
            const valorPrevisto = previsao.dataSync()[0];

            // Mostrando resultado na tela
            textoResultado.innerText =
                "Nota Prevista: " + valorPrevisto.toFixed(2);
        }
    